package com.xumeng;

import java.util.List;
/**
 * ���Ժ���
 * @author xuemeng
 *
 */
public class TestMain {

	public static void main(String[] args) {
		Store w1 = new Store("W1", 1, 2, 2, 100, 5);
		Store w2 = new Store("W2", 2, 1, 2, 100, 10);
		Store w3 = new Store("W3", 1, 3, 1, 100, 15);
		StoreFactory utils = new StoreFactory();
		utils.addStore(w1, ProductType.B);
		utils.addStore(w2, ProductType.B);
		utils.addStore(w3, ProductType.B);
		List<Store> stores = utils.deliverGoods(4, ProductType.B);
		int no = 1;
		for (Store store : stores) {
			System.out.println("����:" + no + "��Ʒ����:" + ProductType.B.toString()
					+ "����:" + store.getOutCount() + "�ֿ�:" + store.getName());
			no++;
		}
	}

}
