package com.xumeng;

/**
 * �ֿ�ʵ����
 * 
 * @author xumeng
 * 
 */
public class Store {
	private String name;// �ֿ�����
	private int aCount;// A��Ʒ����
	private int bCount;// B��Ʒ����
	private int cCount;// C��Ʒ����
	private int distance;// ����
	private int priority;// ���ȼ�
	private int outCount = 0;// ʵ�ʳ�������

	public Store() {
		super();
	}

	public Store(String name, int aCount, int bCount, int cCount, int distance,
			int priority) {
		super();
		this.name = name;
		this.aCount = aCount;
		this.bCount = bCount;
		this.cCount = cCount;
		this.distance = distance;
		this.priority = priority;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getaCount() {
		return aCount;
	}

	public void setaCount(int aCount) {
		this.aCount = aCount;
	}

	public int getbCount() {
		return bCount;
	}

	public void setbCount(int bCount) {
		this.bCount = bCount;
	}

	public int getcCount() {
		return cCount;
	}

	public void setcCount(int cCount) {
		this.cCount = cCount;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	@Override
	public String toString() {
		return "�ֿ���:" + this.name + ",����:" + this.getDistance() + ",���ȼ�:"
				+ this.getPriority() + ",a��Ʒ����:" + this.aCount + ",b��Ʒ����:"
				+ this.getbCount() + ",c��Ʒ����:" + this.cCount;
	}

	public int getOutCount() {
		return outCount;
	}

	public void setOutCount(int outCount) {
		this.outCount = outCount;
	}

}
